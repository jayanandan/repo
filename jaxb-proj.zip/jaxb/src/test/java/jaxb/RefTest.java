package jaxb;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.lab.jaxb.beans.OProperty;
import com.lab.jaxb.beans.Person;

public class RefTest {

	private static List<String> getObjProperties()throws Exception{
		InputStream inputStream = GsonTest.class.getClassLoader().getResourceAsStream("javaObj.txt");
		System.out.println(inputStream);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		String line = null;
		List<String> properties = new ArrayList<String>();
		while((line = br.readLine()) != null){
			properties.add(line.trim());
		}
		return properties;
	}
	
	
	private static void getFieldMap(Class<?> clazz,Map<String,OProperty> fieldMap, List<String> pList) throws NoSuchFieldException, SecurityException{
		
		ObjectUtil objectUtil = ObjectUtil.getInstance();
		String parent = clazz.getSimpleName();
		Class<?> pClazz = clazz;
		for (String path : pList) {
			
			String[] properties = path.split("\\.");
			
			for (int i=1;i<properties.length;i++) {
				String property = objectUtil.getPropertyString(properties[i]);
				
				Field field = pClazz.getDeclaredField(property);
				String fieldPath = parent+"."+field.getName();			
				OProperty oProperty = objectUtil.createProperty(field, fieldPath);
				fieldMap.put(fieldPath, oProperty);
				
				pClazz = oProperty.getClazz();
				parent = fieldPath;
			}
			
			
		}
	}
	
	public static void main(String[] args)throws Exception {
		
		Map<String,OProperty> fieldMap = new TreeMap<String, OProperty>();
		
		List<String> pList = getObjProperties();
		
		getFieldMap(Person.class, fieldMap,pList);
		System.out.println(fieldMap);
		
	}
	
}
