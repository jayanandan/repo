package jaxb;

import static org.junit.Assert.*;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.junit.Test;

import com.lab.jaxb.beans.Service;
import com.lab.jaxb.beans.Services;

public class JaxbMapTest {

	@Test
	public void test() {
		
		try {
			Marshaller marshaller = JAXBContext.newInstance(Services.class).createMarshaller();

			Services mapping = new Services();

			HashMap<String, Service> map = new HashMap<String, Service>();

			Service service = new Service();
			service.setServicename("ServiceA");
			
			Service service2 = new Service();
			service2.setServicename("ServiceB");
						
			map.put("A", service);
			map.put("B", service2);
			
			mapping.setServices(map);
			
			StringWriter writer = new StringWriter();

			marshaller.marshal(mapping, writer);
			
			System.out.println(writer);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
	}

}
