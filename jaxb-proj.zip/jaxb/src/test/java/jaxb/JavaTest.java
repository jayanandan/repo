package jaxb;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import com.lab.jaxb.beans.Address;
import com.lab.jaxb.beans.OProperty;
import com.lab.jaxb.beans.OType;
import com.lab.jaxb.beans.ObjectParser;
import com.lab.jaxb.beans.PathValue;
import com.lab.jaxb.beans.Person;
import com.lab.jaxb.beans.PhoneNo;

public class JavaTest {
	
	private Map<String,OProperty> fieldMap = new TreeMap<String, OProperty>();
	private Person person = new Person();
	
	private static List<String> getObjProperties()throws Exception{
		InputStream inputStream = GsonTest.class.getClassLoader().getResourceAsStream("javaObj.txt");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		String line = null;
		List<String> properties = new ArrayList<String>();
		while((line = br.readLine()) != null){
			properties.add(line.trim());
		}
		return properties;
	}
	
	
	private static void getFieldMap(Class<?> clazz,Map<String,OProperty> fieldMap, List<String> pList) throws NoSuchFieldException, SecurityException{
		
		ObjectUtil objectUtil = ObjectUtil.getInstance();
		
		for (String path : pList) {
			Class<?> pClazz = clazz;
			String parent = clazz.getSimpleName();
			
			String[] properties = path.split("\\.");
			
			for (int i=1;i<properties.length;i++) {
				String property = objectUtil.getPropertyString(properties[i]);
				String fieldPath = parent+"."+property;
				
				Field field = pClazz.getDeclaredField(property);
				
				if(fieldMap.containsKey(fieldPath)){
					parent = fieldPath;
					pClazz = fieldMap.get(fieldPath).getClazz();
					continue;
				}
				
				OProperty oProperty = new OProperty();
				oProperty.setPath(fieldPath);
				field.setAccessible(true);
				if(field.getType().equals(List.class)){
					oProperty.setType(OType.ListType);
					oProperty.setClazz(objectUtil.getGenericType(field));
					
				}else{
					if(i==properties.length-1){
						oProperty.setType(OType.PrimitiveType);
					}else{
						oProperty.setType(OType.ObjectType);
					}
					oProperty.setClazz(field.getType());
				}
				oProperty.setField(field);
				
				fieldMap.put(fieldPath, oProperty);
				
				pClazz = oProperty.getClazz();
				parent = fieldPath;
			}
			
			
		}
	}
	
	@Before
	public void prepare() {
	try {

		List<String> pList = getObjProperties();
		getFieldMap(Person.class, fieldMap,pList);
		
		List<Address> addressList = new ArrayList<Address>();
		
		Address address = new Address();
		address.setCity("Chennai");
		PhoneNo ph1 = new PhoneNo();
		ph1.setPhoneNo(9894470671L);
		address.setPhoneNo(ph1);
		
		Address address1 = new Address();
		address1.setCity("Madurai");
		
		addressList.add(address);
		addressList.add(address1);
		
		person.setAddresses(addressList);
		person.setName("Jayanandan");
		
		
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void test() throws Exception{
		
		List<String> pList = getObjProperties();
		ObjectParser parser = new ObjectParser(person);
		for (String path : pList) {
			parser.parseObject(path, fieldMap);			
		}
		Set<PathValue> pathValues = parser.getPathValues();
		System.out.println(pathValues);
		
	}

}
