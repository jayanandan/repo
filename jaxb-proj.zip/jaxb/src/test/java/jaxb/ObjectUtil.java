package jaxb;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lab.jaxb.beans.OProperty;
import com.lab.jaxb.beans.OType;
import com.lab.jaxb.beans.PathValue;

public class ObjectUtil {
	private static ObjectUtil instance = new ObjectUtil();
	private ObjectUtil(){}
	
	public static ObjectUtil getInstance(){
		return instance;		
	}
	
	public boolean isIndexedProperty(String property){
		if(property != null && property.indexOf("[")>0){
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public int getIndex(String property){
		int index = -1;
		if(!isIndexedProperty(property)){
			return index;
		}
		
		String idxStr = property.substring(property.indexOf("[")+1,property.indexOf("]"));
		if(idxStr.trim().length()==0){
			index=-2;//for all property
		}else{
			index = Integer.parseInt(idxStr);			
		}
		return index;
	}
	
	public String getPropertyString(String property){
		String pStr = property;
		if(property.indexOf("[")>0){
			pStr = property.substring(0,property.indexOf("["));
		}
		return pStr;
	}
	
	public String concatPath(String[] properties){
		StringBuilder path = new StringBuilder();
		for (String _path : properties) {
			path.append(_path).append(".");
		}
		return path.substring(0, path.length()-1);
	}
	
	public <T> T[] replace(T[] array,int index,T value){
		T[] copyOf = Arrays.copyOf(array, array.length);
		copyOf[index]=value;
		return copyOf;
	}
	
	public Class<?> getGenericType(Field field){
		Class<?> genericType = null;
		if(field.getType().equals(List.class)){
			ParameterizedType listType = (ParameterizedType) field.getGenericType();
			genericType = (Class<?>) listType.getActualTypeArguments()[0];			
		}
		return genericType;
	}
	
	public static void main(String[] args) {
		String path = "Person.addresses[].city";
		int fromIndex=0,tmpIdx=0;
		for(;path.indexOf(".",fromIndex)>0;){
			fromIndex = path.indexOf(".", fromIndex);
			String property = path.substring(tmpIdx,fromIndex);
			fromIndex+=1;
			tmpIdx = fromIndex;
			System.out.println(property);
		}
		System.out.println(path.substring(fromIndex));
	}

}
