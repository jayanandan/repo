package com.lab.jaxb.beans;

import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.lab.jaxb.adapter.ServiceMapAdapter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Services {

	@XmlElement(name="service")
	@XmlJavaTypeAdapter(ServiceMapAdapter.class)
	private Map<String,Service> services;

	public Map<String, Service> getServices() {
		return services;
	}

	public void setServices(Map<String, Service> services) {
		this.services = services;
	}
		
}
