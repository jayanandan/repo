package com.lab.jaxb.beans;

public class Address {
	private String city;
	private PhoneNo phoneNo;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public PhoneNo getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(PhoneNo phoneNo) {
		this.phoneNo = phoneNo;
	}
	
}
