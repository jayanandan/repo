package com.lab.jaxb.beans;

public class PathValue{

	private String fromPath;
	private String toPath;
	private Object value;
	public String getFromPath() {
		return fromPath;
	}
	public void setFromPath(String fromPath) {
		this.fromPath = fromPath;
	}
	public String getToPath() {
		return toPath;
	}
	public void setToPath(String toPath) {
		this.toPath = toPath;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fromPath == null) ? 0 : fromPath.hashCode());
		result = prime * result + ((toPath == null) ? 0 : toPath.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PathValue other = (PathValue) obj;
		if (fromPath == null) {
			if (other.fromPath != null)
				return false;
		} else if (!fromPath.equals(other.fromPath))
			return false;
		if (toPath == null) {
			if (other.toPath != null)
				return false;
		} else if (!toPath.equals(other.toPath))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PathValue [fromPath=" + fromPath + ", toPath=" + toPath + ", value=" + value + "]";
	}	
}
