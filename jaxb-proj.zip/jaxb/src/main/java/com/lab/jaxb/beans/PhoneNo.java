package com.lab.jaxb.beans;

public class PhoneNo {
	private Long phoneNo;

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}	
}
