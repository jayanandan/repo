package com.lab.jaxb.beans;

import java.lang.reflect.Field;

public class OProperty {

	private String path;
	private int index=-1;//index of containing object in the list/array
	private OType type;
	private Class<?> clazz;
	private Field field;
	
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public OType getType() {
		return type;
	}
	public void setType(OType type) {
		this.type = type;
	}	
	public Class<?> getClazz() {
		return clazz;
	}
	public void setClazz(Class<?> clazz) {
		this.clazz = clazz;
	}
	public Field getField() {
		return field;
	}
	public void setField(Field field) {
		this.field = field;
	}
	@Override
	public String toString() {
		return "OProperty [path=" + path + ", index=" + index + ", type=" + type + ", clazz=" + clazz + ", field="
				+ field + "]";
	}
	
}
