package com.lab.jaxb.beans;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jaxb.ObjectUtil;

public class ObjectParser {
	
	private Set<PathValue> pathValues = new HashSet<PathValue>();
	
	private final Map<String,Object> valueMap = new HashMap<String, Object>();
	private Object root = null;
	
	public ObjectParser(Object root){
		this.root=root;
	}

	public Set<PathValue> getPathValues() {
		return pathValues;
	}

	public void parseObject(String path,Map<String,OProperty> fieldMap) throws Exception{

		PathValue pv = new PathValue();
		pv.setFromPath(path);
		
		if(pathValues.contains(pv)){
			return;
		}
		
		ObjectUtil objectUtil = ObjectUtil.getInstance();		
		
		String[] properties = path.split("\\.");
		String parent = properties[0];
		Object pObj = root;
		StringBuilder fromPath = new StringBuilder(parent);
		
		A : for (int i=1;i<properties.length;i++) {
			String property = objectUtil.getPropertyString(properties[i]);
			
			String fieldPath = parent+"."+property;
			fromPath.append(".").append(property);
			OProperty oProperty = fieldMap.get(fieldPath);
			
			Object object =null;
			if(valueMap.containsKey(fieldPath)){
				object = oProperty.getField().get(pObj);
			}else{
				object = oProperty.getField().get(pObj);				
			}
			
			if(object==null){
				pv.setFromPath(fromPath.toString());
				pv.setValue(object);
				pathValues.add(pv);
				continue;
			}
			
			OType oType = oProperty.getType();
			switch (oType) {
				case ArrayType:{		
					break;	
				}
				case ListType :{
					int index = objectUtil.getIndex(properties[i]);
					List objList = (List)object;
					if(index>=0){//for specified index
						pObj = objList.get(index);
						fromPath.append("["+index+"]");
					}else{//for all index
						int size = objList.size();
						for(int j=0;j<size;j++){
							String[] listProperty = objectUtil.replace(properties,i,property+"["+j+"]");							
							parseObject(objectUtil.concatPath(listProperty), fieldMap);					 
						}
						break A;
					}
					break;					
				}case ObjectType:{
					pObj = object;
					break;
				}case PrimitiveType:{		
					pv.setFromPath(fromPath.toString());
					pv.setValue(object);
					pathValues.add(pv);
					break;
				}					
				default:{
					throw new Exception("Unsupported type");			
				}
			}
			parent = fieldPath;				
		}
	}
	
}
