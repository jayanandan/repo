package com.lab.jaxb.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import com.lab.jaxb.beans.Service;

public class ServiceMapAdapter extends XmlAdapter<ArrayList<Service>, HashMap<String, Service>> {

	@Override
	public ArrayList<Service> marshal(HashMap<String, Service> arg0) throws Exception {
		ArrayList<Service> list = new ArrayList<Service>();
		for(Service _service : arg0.values()){
			list.add(_service);
		}
		return list;
	}

	@Override
	public HashMap<String, Service> unmarshal(ArrayList<Service> arg0) throws Exception {
		HashMap<String,Service> map = new HashMap<String, Service>();
		for(Service _service : arg0){
			map.put(_service.getServicename(), _service);
		}
		return map;
	}

	
	
	

}
