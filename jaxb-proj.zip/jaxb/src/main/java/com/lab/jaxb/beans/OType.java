package com.lab.jaxb.beans;

public enum OType {
	ObjectType,ArrayType,ListType,PrimitiveType;	
}
