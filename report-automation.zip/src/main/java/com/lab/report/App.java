package com.lab.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Hello world!
 *
 */
public class App 
{
	private static Properties props;
	public static WebDriver driver;
	public static String geckoDriverPath;
	public static String chromeDriverPath;
	public static String ieDriverPath;
	public static String downloadFilepath;
	public static enum Months {
	
		 JAN(1,"January"),
		 FEB(2,"February"),
		 MAR(3,"March"),
		 APR(4,"April"),
		 MAY(5,"May"),
		 JUN(6,"June"),
		 JUL(7,"July"),
		 AUG(8,"August"),
		 SEP(9,"September"),
		 OCT(10,"October"),
		 NOV(11,"November"),
		 DEC(12,"December");
		Months(int no,String txt){
			this.no=no;
			this.txt=txt;
		}
		int no;
		String txt;
		public static String getMonth(int no){
			Months[] months = Months.values();
			for (Months month: months) {
				if(month.no==no){
					return month.txt;
				}
			}
			return null;
		}
		
	}
	
	
	
	public App()throws Exception{
	
		
		props = new Properties();
		File jarPath=new File(App.class.getProtectionDomain().getCodeSource().getLocation().getPath());
        String propertiesPath=jarPath.getParentFile().getAbsolutePath();
		InputStream is = new FileInputStream(propertiesPath+File.separator+"report.properties");
		props.load(is);
		geckoDriverPath = "./geckodirver.exe";
		chromeDriverPath="./chromedriver.exe";
		ieDriverPath = "./IEDriverServer.exe";
		downloadFilepath = props.getProperty("report.download.dir");
		
	}
	
	private boolean validateParams(Params params){
		String years = props.getProperty("year");
		String[] selectYr = null;
		if(years != null && years.trim().length()>0){
			 selectYr = years.trim().split(",");
		}
		String months = props.getProperty("month");
		String[] selectMonth = null;
		if(null != months && months.trim().length()>0){
			selectMonth = months.trim().split(",");
		}
		
		String dates = props.getProperty("date");
		String[] selectDt = null;
		if(null != dates && dates.trim().length()>0){
			selectDt = dates.trim().split(",");
		}
		params.setYear(selectYr);
		params.setMonths(selectMonth);
		params.setDates(selectDt);
		
		if(null != selectYr && null != selectMonth && null != selectDt
				&& selectYr.length>0 && selectMonth.length>0 && selectDt.length > 0){
			return true;
		}
		return false;
	}
	
	public static void main(String[] args)throws Exception {
		
		App app = new App();
		Params params = new Params();
		if(app.validateParams(params)){
			app.initChromeDriver();
			app.test(params);
		}else{
			System.err.println("Please check the year, month and date values");
		}
		
	}
	
	public void test(Params params)throws Exception{

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://jpmcportal.cognizant.com/");
		
		WebElement handyReportEle = driver.findElement(By.xpath("//div[@id='ctl00_cphContent_pnlHandy']/div"));
		handyReportEle.click();
		Thread.sleep(1000);
		WebElement table = driver.findElement(By.xpath("//div[@id='ctl00_cphContent_pnlExpand']/table"));
		WebElement td = table.findElement(By.xpath("//tr/td[contains(text(),'Assignment Listing Report')]"));
		td.click();
		
		String selectedYr = params.year[0].trim();
		String selectedMonth=Months.getMonth(Integer.parseInt(params.months[0].trim()));
		
		for(String date:params.dates){
			downloadForSelection(selectedYr, selectedMonth, date.trim());
		}
		
	}

	private void downloadForSelection(String year,String month,String date)throws Exception{
		Select yearEle = new Select(driver.findElement(By.name("ctl00$cphContent$drpYear")));		
		yearEle.selectByValue(year);
		WaitForAjax();
		
		Select monthEle = new Select(driver.findElement(By.name("ctl00$cphContent$drpDate")));
		monthEle.selectByValue(month);
		WaitForAjax();
		
		Select dateEle = new Select(driver.findElement(By.name("ctl00$cphContent$drpDts")));
		dateEle.selectByValue(date);
		WaitForAjax();		
		
		WebElement exportEle = driver.findElement(By.id("ctl00_cphContent_btn_Populate"));
		exportEle.click();
	}
	
	public void WaitForAjax() throws InterruptedException
    {

        while (true)
        {

            Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor)driver).executeScript("return jQuery.active == 0");
            if (ajaxIsComplete){
                break;
            }
            Thread.sleep(100);
        }
    }
	private void initIEDriver(){
		System.setProperty("webdriver.ie.driver", ieDriverPath);
		driver = new InternetExplorerDriver();
	}
	
	private void initChromeDriver(){		 
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadFilepath);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);
		driver = new ChromeDriver(options);
	}
	
	private void initFirefoxDriver() {
		System.setProperty("webdriver.gecko.driver", geckoDriverPath);
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("browser.download.folderList", 2);
		profile.setPreference("browser.download.dir",downloadFilepath);
		profile.setPreference("browser.download.useDownloadDir", true);
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/vnd.ms-excel");
		FirefoxOptions firefoxOptions = new FirefoxOptions();
		firefoxOptions.setProfile(profile);
		driver = new FirefoxDriver(firefoxOptions);
	}
	
	
}
